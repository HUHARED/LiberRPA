# FileName: UnexpectedNormalPath.py
# <LiberRPA imports: managed>
# This block is managed by LiberRPA. Do not edit it manually.
# ruff: isort: off
# ruff: isort: on
# </LiberRPA imports: managed>


def main() -> None:
    raise AssertionError(
        "The Component Error Block completed without raising the expected ValueError."
    )


if __name__ == "__main__":
    main()
