# FileName: HandWrittenSnippets.py
# <LiberRPA imports: managed>
# This block is managed by LiberRPA. Do not edit it manually.
# ruff: isort: off
from liberrpa.Modules import (
    Log,
)
from ExampleDelay import (
    Delay as ExampleDelay_Delay,
    Preset as ExampleDelay_Preset,
)
# ruff: isort: on
# </LiberRPA imports: managed>


def main() -> None:
    floatShortSeconds = ExampleDelay_Preset.get_preset_seconds(presetName="short")
    Log.info(
        f"Short preset from the hand-written expression Snippet: {floatShortSeconds}"
    )

    Log.info("Start ExampleDelay demo.")
    ExampleDelay_Delay.sec_1()
    ExampleDelay_Delay.sec_3()
    _ = ExampleDelay_Preset.delay_by_preset(presetName="short")
    Log.info("ExampleDelay demo completed.")


if __name__ == "__main__":
    main()
