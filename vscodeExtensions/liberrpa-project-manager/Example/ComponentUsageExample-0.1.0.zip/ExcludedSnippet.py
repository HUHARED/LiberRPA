# FileName: ExcludedSnippet.py
# <LiberRPA imports: managed>
# This block is managed by LiberRPA. Do not edit it manually.
# ruff: isort: off
from liberrpa.Modules import (
    Log,
)
from ExampleDelay import (
    Delay as ExampleDelay_Delay,
)
# ruff: isort: on
# </LiberRPA imports: managed>


def main() -> None:
    ExampleDelay_Delay.sec_1()

    if not callable(ExampleDelay_Delay.sec_20):
        raise RuntimeError(
            "Excluded Component function was not available through Python."
        )
    Log.info(
        "sec_20 is callable through the Component Python API even though its Snippet is excluded."
    )
    # ExampleDelay_Delay.sec_20()


if __name__ == "__main__":
    main()
