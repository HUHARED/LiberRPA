# FileName: UpdatedApis.py
# <LiberRPA imports: managed>
# This block is managed by LiberRPA. Do not edit it manually.
# ruff: isort: off
from ExampleDelay import (
    Experimental as ExampleDelay_Experimental,
)
# ruff: isort: on
# </LiberRPA imports: managed>


def main() -> None:
    ExampleDelay_Experimental.delay_for_review(seconds=0.1)
    ExampleDelay_Experimental.delay_cooperatively(seconds=0.1)
    ExampleDelay_Experimental.delay_sequence(secondList=[0.1, 0.2])
    ExampleDelay_Experimental.delay_with_default(seconds=0.1)
    ExampleDelay_Experimental.function_with_nested_helper(seconds=0.1)


if __name__ == "__main__":
    main()
