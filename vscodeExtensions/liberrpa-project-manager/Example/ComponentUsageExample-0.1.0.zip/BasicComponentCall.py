# FileName: BasicComponentCall.py
# <LiberRPA imports: managed>
# This block is managed by LiberRPA. Do not edit it manually.
# ruff: isort: off
from ExampleDelay import (
    Delay as ExampleDelay_Delay,
)
# ruff: isort: on
# </LiberRPA imports: managed>


def main() -> None:
    ExampleDelay_Delay.delay_with_message(
        message="ExampleDelay is available through its public package.",
        seconds=0.5,
        logLevel="INFO",
    )


if __name__ == "__main__":
    main()
