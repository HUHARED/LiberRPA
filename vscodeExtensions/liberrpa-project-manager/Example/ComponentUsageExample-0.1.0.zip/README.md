# Component Usage Example

This final-state Flow Project demonstrates how to add and use the `ExampleDelay` Component in Python Blocks.

The Project includes:

- a direct Component requirement in `flow.json`;
- an exact resolved version in `components.lock.json`;
- the installed Component package in `_Components`;
- automatically generated and hand-written Component Snippets;
- a Component package resource;
- a Component exception handled through a Flowchart Exception Line.

Open `project.flow`, then:

- press `F5` to debug the complete Flow Project;
- press `Ctrl+F5` to run the complete Flow Project.

The example uses the following Blocks:

| Block                      | Purpose                                                               |
| -------------------------- | --------------------------------------------------------------------- |
| `Basic Component Call`   | Call an automatically generated Component API.                        |
| `Preset Resource`        | Read and use a resource packaged inside the Component.                |
| `Hand-written Snippets`  | Use hand-written line and cursor Snippets.                            |
| `Updated APIs`           | Call APIs provided by `ExampleDelay 1.0.1`.                         |
| `Excluded Snippet`       | Show that Snippet exclusion does not remove the Python API.           |
| `Component Error`        | Raise an expected Component validation error.                         |
| `Handle Component Error` | Continue through the Exception Line and inspect `PrjArgs.errorObj`. |
| `Unexpected Normal Path` | Fail the test if the expected exception is not raised.                |

For detailed usage, see:

- [liberrpa-project-manager](https://github.com/HUHARED/LiberRPA/blob/main/vscodeExtensions/liberrpa-project-manager/README.md)
- [liberrpa-snippets-tree](https://github.com/HUHARED/LiberRPA/blob/main/vscodeExtensions/liberrpa-snippets-tree/README.md)
- [liberrpa-flowchart](https://github.com/HUHARED/LiberRPA/blob/main/vscodeExtensions/liberrpa-flowchart/README.md)
