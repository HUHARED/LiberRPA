# FileName: PresetResource.py
# <LiberRPA imports: managed>
# This block is managed by LiberRPA. Do not edit it manually.
# ruff: isort: off
from liberrpa.Modules import (
    Log,
)
from ExampleDelay import (
    Preset as ExampleDelay_Preset,
)
# ruff: isort: on
# </LiberRPA imports: managed>


def main() -> None:
    listPresetName = ExampleDelay_Preset.get_preset_names()
    floatShortSeconds = ExampleDelay_Preset.get_preset_seconds(presetName="short")
    floatActualSeconds = ExampleDelay_Preset.delay_by_preset(presetName="short")
    Log.info(
        f"Preset names: {listPresetName}; "
        f"short preset: {floatShortSeconds}s; "
        f"actual delay: {floatActualSeconds}s."
    )


if __name__ == "__main__":
    main()
