# FileName: HandleComponentError.py
# <LiberRPA imports: managed>
# This block is managed by LiberRPA. Do not edit it manually.
# ruff: isort: off
from liberrpa.Modules import (
    Log,
    PrjArgs,
)
# ruff: isort: on
# </LiberRPA imports: managed>


def main() -> None:
    Log.info(
        f"The Component error was caught by the Flowchart error path: {PrjArgs.errorObj!r}"
    )


if __name__ == "__main__":
    main()
