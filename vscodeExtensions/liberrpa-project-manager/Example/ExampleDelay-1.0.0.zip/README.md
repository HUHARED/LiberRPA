# Example Delay

This Component accompanies the [Example Delay Component walkthrough](https://github.com/HUHARED/LiberRPA/blob/main/vscodeExtensions/liberrpa-project-manager/ExampleDelayComponent.md).

Version `1.0.0` intentionally contains several functions that produce Publish diagnostics. They are used to demonstrate generated, skipped, and warning results.
