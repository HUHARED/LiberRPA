# FileName: Preset.py


# <LiberRPA imports: managed>
# This block is managed by LiberRPA. Do not edit it manually.
# ruff: isort: off
from liberrpa.Modules import (
    Log,
    delay,
    get_component_resource_path,
)
# ruff: isort: on
# </LiberRPA imports: managed>

from ExampleDelay._Validation import seconds_to_milliseconds

import json
from pathlib import Path
from typing import Literal

_STR_PRESET_CONFIG_RELATIVE_PATH = "_Config/presets.json"


def _load_preset_second_dict() -> dict[str, float]:
    strConfigPath = get_component_resource_path(relativePath=_STR_PRESET_CONFIG_RELATIVE_PATH)

    with Path(strConfigPath).open("r", encoding="utf-8") as fileObj:
        value: object = json.load(fileObj)

    if not isinstance(value, dict):
        raise ValueError("The preset configuration root value must be an object.")

    dictPresetSecond: dict[str, float] = {}
    for strPresetName, secondsValue in value.items():
        if not isinstance(strPresetName, str) or strPresetName == "":
            raise ValueError("Every preset name must be a non-empty string.")

        if isinstance(secondsValue, bool) or not isinstance(secondsValue, int | float):
            raise ValueError(f"Preset {strPresetName!r} must use a numeric second value.")

        floatSeconds = float(secondsValue)
        if floatSeconds < 0:
            raise ValueError(f"Preset {strPresetName!r} cannot use a negative second value.")

        dictPresetSecond[strPresetName] = floatSeconds

    return dictPresetSecond


def _get_preset_seconds(
    presetName: Literal["short", "medium", "long"],
) -> float:
    dictPresetSecond = _load_preset_second_dict()

    try:
        return dictPresetSecond[presetName]
    except KeyError as e:
        raise ValueError(f"Unknown delay preset: {presetName!r}.") from e


@Log.trace(level="DEBUG")
def get_preset_names() -> list[str]:
    """Return the available delay preset names."""
    return sorted(_load_preset_second_dict())


@Log.trace(level="DEBUG")
def get_preset_seconds(
    presetName: Literal["short", "medium", "long"] = "short",
) -> float:
    """
    Return the configured number of seconds for a delay preset.

    Parameters:
        presetName: The preset name to read.

    Returns:
        float: The configured delay duration in seconds.
    """
    return _get_preset_seconds(presetName)


@Log.trace(level="DEBUG")
def delay_by_preset(
    presetName: Literal["short", "medium", "long"] = "short",
) -> float:
    """
    Delay using a named preset stored in the Component package resources.

    Parameters:
        presetName: The preset name to use.

    Returns:
        float: The actual delay duration in seconds.
    """
    floatSeconds = _get_preset_seconds(presetName)
    delay(seconds_to_milliseconds(floatSeconds))
    return floatSeconds


if __name__ == "__main__":
    Log.set_level(level="VERBOSE", loggerType="both")
    print(get_preset_names())
    print(delay_by_preset(presetName="short"))
