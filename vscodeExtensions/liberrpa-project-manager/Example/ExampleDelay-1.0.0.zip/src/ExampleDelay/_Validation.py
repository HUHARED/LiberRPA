# FileName: _Validation.py


def seconds_to_milliseconds(seconds: float) -> int:
    """Convert non-negative seconds to milliseconds."""
    if seconds < 0:
        raise ValueError("seconds must be greater than or equal to 0.")

    return round(seconds * 1000)
