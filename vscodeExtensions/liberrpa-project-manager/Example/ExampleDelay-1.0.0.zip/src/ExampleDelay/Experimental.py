# FileName: Experimental.py

# This module intentionally contains functions that produce Publish diagnostics.
# It is used to demonstrate the difference between generated, skipped, and warning results.

# <LiberRPA imports: managed>
# This block is managed by LiberRPA. Do not edit it manually.
from liberrpa.Modules import (
    Log,
    delay,
)
# </LiberRPA imports: managed>

from ExampleDelay._Validation import seconds_to_milliseconds

import asyncio


def _get_default_seconds() -> float:
    return 1.0


@Log.trace(level="DEBUG")
def delay_for_review(seconds: float = 1.0) -> None:
    # Intentionally no docstring: an automatic Snippet is generated with a warning.
    delay(seconds_to_milliseconds(seconds))


async def delay_cooperatively(seconds: float = 1.0) -> None:
    """
    Delay without blocking an asyncio event loop.

    Parameters:
        seconds: The non-negative number of seconds to delay.
    """
    await asyncio.sleep(seconds)


def delay_sequence(*seconds: float) -> None:
    """
    Delay once for every supplied duration.

    Parameters:
        seconds: Delay durations in seconds.
    """
    for floatSeconds in seconds:
        delay(seconds_to_milliseconds(floatSeconds))


def delay_with_default(seconds: float = _get_default_seconds()) -> None:
    """
    Delay using a dynamically calculated default value.

    Parameters:
        seconds: The non-negative number of seconds to delay.
    """
    delay(seconds_to_milliseconds(seconds))


@Log.trace(level="DEBUG")
def function_with_nested_helper(seconds: float = 1.0) -> None:
    """
    Demonstrate that only the public top-level function becomes an automatic Snippet.

    Parameters:
        seconds: The non-negative number of seconds to delay.
    """

    def _run_delay() -> None:
        delay(seconds_to_milliseconds(seconds))

    _run_delay()
