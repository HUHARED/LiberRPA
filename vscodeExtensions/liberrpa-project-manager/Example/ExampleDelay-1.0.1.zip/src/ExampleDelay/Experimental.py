# FileName: Experimental.py

# This module contains the cleaned versions of the diagnostic examples introduced in ExampleDelay 1.0.0.

# <LiberRPA imports: managed>
# This block is managed by LiberRPA. Do not edit it manually.
# ruff: isort: off
from liberrpa.Modules import (
    Log,
    delay,
)
# ruff: isort: on
# </LiberRPA imports: managed>

from ExampleDelay._Validation import seconds_to_milliseconds


@Log.trace(level="DEBUG")
def delay_for_review(seconds: float = 1.0) -> None:
    """
    Delay for a configurable duration used during the publication walkthrough.

    Parameters:
        seconds: The non-negative number of seconds to delay.
    """
    delay(seconds_to_milliseconds(seconds))


@Log.trace(level="DEBUG")
def delay_cooperatively(seconds: float = 1.0) -> None:
    """
    Delay through the standard synchronous LiberRPA runtime.

    Parameters:
        seconds: The non-negative number of seconds to delay.
    """
    delay(seconds_to_milliseconds(seconds))


@Log.trace(level="DEBUG")
def delay_sequence(secondList: list[float]) -> None:
    """
    Delay once for every duration in a list.

    Parameters:
        secondList: Delay durations in seconds.
    """
    for floatSeconds in secondList:
        delay(seconds_to_milliseconds(floatSeconds))


@Log.trace(level="DEBUG")
def delay_with_default(seconds: float = 1.0) -> None:
    """
    Delay using a static default value that can be represented in a Snippet.

    Parameters:
        seconds: The non-negative number of seconds to delay.
    """
    delay(seconds_to_milliseconds(seconds))


@Log.trace(level="DEBUG")
def function_with_nested_helper(seconds: float = 1.0) -> None:
    """
    Demonstrate that only the public top-level function becomes an automatic Snippet.

    Parameters:
        seconds: The non-negative number of seconds to delay.
    """

    def _run_delay() -> None:
        delay(seconds_to_milliseconds(seconds))

    _run_delay()
