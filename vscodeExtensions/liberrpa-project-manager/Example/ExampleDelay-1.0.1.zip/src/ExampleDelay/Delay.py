# FileName: Delay.py


# <LiberRPA imports: managed>
# This block is managed by LiberRPA. Do not edit it manually.
from liberrpa.Modules import (
    Log,
    delay,
)
# </LiberRPA imports: managed>

from ExampleDelay._Validation import seconds_to_milliseconds

from typing import Literal


def _delay_seconds(seconds: float) -> None:
    delay(seconds_to_milliseconds(seconds))


def _write_log(message: str, logLevel: Literal["VERBOSE", "DEBUG", "INFO"]) -> None:
    match logLevel:
        case "VERBOSE":
            Log.verbose(message)
        case "DEBUG":
            Log.debug(message)
        case "INFO":
            Log.info(message)
        case _:
            raise ValueError(f"Unsupported log level: {logLevel!r}.")


@Log.trace(level="DEBUG")
def delay_seconds(seconds: float) -> None:
    """
    Delay for the specified number of seconds.

    Parameters:
        seconds: The non-negative number of seconds to delay.
    """
    _delay_seconds(seconds)


@Log.trace(level="DEBUG")
def delay_with_message(
    message: str,
    seconds: float = 1.0,
    *,
    logLevel: Literal["VERBOSE", "DEBUG", "INFO"] = "INFO",
) -> None:
    """
    Write a message and then delay.

    Parameters:
        message: The message to write before delaying.
        seconds: The non-negative number of seconds to delay.
        logLevel: The LiberRPA log level used for the message.
    """
    _write_log(message=message, logLevel=logLevel)
    _delay_seconds(seconds)


@Log.trace(level="DEBUG")
def sec_1() -> None:
    """Delay for 1 second."""
    _delay_seconds(1)


@Log.trace(level="DEBUG")
def sec_3() -> None:
    """Delay for 3 seconds."""
    _delay_seconds(3)


@Log.trace(level="DEBUG")
def sec_5() -> None:
    """Delay for 5 seconds."""
    _delay_seconds(5)


@Log.trace(level="DEBUG")
def sec_10() -> None:
    """Delay for 10 seconds."""
    _delay_seconds(10)


@Log.trace(level="DEBUG")
def sec_20() -> None:
    """Delay for 20 seconds."""
    _delay_seconds(20)


if __name__ == "__main__":
    Log.set_level(level="VERBOSE", loggerType="both")

    sec_1()
    sec_3()
    sec_5()
    Log.set_level(level="DEBUG", loggerType="both")
    sec_10()
    sec_20()
