# Example Delay

This Component accompanies the [Example Delay Component walkthrough](https://github.com/HUHARED/LiberRPA/blob/main/vscodeExtensions/liberrpa-project-manager/ExampleDelayComponent.md).

Version `1.0.1` contains the cleaned versions of the diagnostic examples introduced in version `1.0.0`.
