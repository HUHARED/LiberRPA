# FileName: EmptyInput.py
# <LiberRPA imports: managed>
# This block is managed by LiberRPA. Do not edit it manually.
# ruff: isort: off
from liberrpa.Modules import (
    Log,
)
# ruff: isort: on
# </LiberRPA imports: managed>


def main() -> None:
    Log.info("No text was entered.")


if __name__ == "__main__":
    main()
