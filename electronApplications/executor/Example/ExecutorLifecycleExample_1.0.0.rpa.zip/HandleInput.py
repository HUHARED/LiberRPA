# FileName: HandleInput.py
# <LiberRPA imports: managed>
# This block is managed by LiberRPA. Do not edit it manually.
# ruff: isort: off
from liberrpa.Modules import (
    Log,
    delay,
    Str,
    CustomArgs,
)
# ruff: isort: on
# </LiberRPA imports: managed>


def main() -> None:
    strMode = Str.case_to_upper(strObj=CustomArgs["inputText"]).strip()

    match strMode:
        case "ERROR":
            raise RuntimeError("Intentional error raised by ExecutorLifecycleExample.")

        case "WAIT":
            Log.info("WAIT mode started.")
            for intIndex in range(1, 181, 1):
                delay(1000)

                if intIndex % 10 == 0:
                    Log.info(f"WAIT mode: {intIndex} seconds elapsed.")

            Log.info("WAIT mode completed.")

        case _:
            Log.info(f"User input: {CustomArgs['inputText']}")


if __name__ == "__main__":
    main()
