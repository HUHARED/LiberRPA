# Executor Lifecycle Example

## Overview

`ExecutorLifecycleExample` is a small Flow Project for demonstrating and
testing the run lifecycle handled by LiberRPA Executor.

The Project asks for text, uses a Flowchart `Choose` node to distinguish
empty and non-empty input, and provides `ERROR` and `WAIT` modes for
exercising different run outcomes.

## Flow

```mermaid
flowchart TD
    A["Start"]
    B["Get Input"]
    C{"Has input text?"}
    D["Handle Input"]
    E["Empty Input"]
    F["End"]

    A --> B
    B --> C
    C -->|True| D
    C -->|False| E
    D --> F
    E --> F
```

| Scenario     | Input / action                                                       | Python status  | Executor status |
| ------------ | -------------------------------------------------------------------- | -------------- | --------------- |
| Empty input  | Leave the input empty                                                | `completed`  | `completed`   |
| Normal input | Enter ordinary text                                                  | `completed`  | `completed`   |
| Error        | Enter `ERROR`                                                      | `error`      | `error`       |
| Cancel       | Enter `WAIT`, then cancel the run                                  | `terminated` | `cancel`      |
| Timeout      | Enter `WAIT` with a timeout shorter than 180 seconds               | `terminated` | `timeout`     |
| Interrupted  | Leave an Executor run recorded as `running`, then restart Executor | —             | `interrupted` |

> `cancel`, `timeout`, and `interrupted` are Executor lifecycle outcomes. The Flow Project itself does not implement these states.
