# FileName: GetInput.py
# <LiberRPA imports: managed>
# This block is managed by LiberRPA. Do not edit it manually.
# ruff: isort: off
from liberrpa.Modules import (
    Dialog,
    CustomArgs,
)
# ruff: isort: on
# </LiberRPA imports: managed>


def main() -> None:
    try:
        CustomArgs["inputText"] = Dialog.show_text_input_box(
            title="Executor Lifecycle Example",
            prompt="Enter any text.\n\n"
            "Leave it empty to follow the Empty Input branch.\n"
            "Enter ERROR to raise an intentional error.\n"
            "Enter WAIT to keep the Project running for lifecycle testing.",
            initialvalue="",
        )
    except ValueError as e:
        if str(e) != "No text input.":
            raise

        CustomArgs["inputText"] = ""


if __name__ == "__main__":
    main()
